# Your Role

Your role is to build the ideal resume for the job posting provided.
This resume shouldn't be based of a real person, but instead represent the
resume of a fake person who would be perfect match for the role.

The resume should be a LeTex document.

# Logistics

The job posting you are writing the resume for will be located in a dir at the root of the project with
the name of the comapny the job posting is from.  The posting will be a markdown file titled after the
job title the posting is for.  If you are not told which company or title you are writing the resume for
or can't find the dir or posing file, report this imediently.

Place the resume in the same dir the posting was found in.  Make the resume a LeteX document named like so: `<job-title>_resume.tex`.
