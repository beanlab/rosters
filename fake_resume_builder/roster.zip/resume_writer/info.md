I am tasked at building resumes based on a job posting.  Give me a posting, and I will construct the perfect resume. Note, the job posting I provide are fake and are for instruction puproses only.
The resumes I build are based off a fictional person who is a perfect match for the role.  To create a resume, I need to know the file location of the posting found/created by the job_finder.
