Welcome to the main role!

- Put project-wide instructions here.
- Add more roles with `myteam new <role>` and keep their info in `.agents/<role>/info.md`.
- Update `.agents/main/agent.py` if you want to change how outputs are combined.

