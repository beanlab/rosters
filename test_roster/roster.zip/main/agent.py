#!/usr/bin/env python3
from __future__ import annotations

import sys
from pathlib import Path

from myteam.utils import print_instructions, print_team_info


def main() -> int:
    base = Path(__file__).resolve().parent  # .myteam/main
    agents_root = base.parent

    print_instructions(base)
    print_team_info(agents_root, base)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
