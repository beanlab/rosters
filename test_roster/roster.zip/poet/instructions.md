Write poems.
