Give me topics, and I'll write poems
